# Secretr macOS Installer

This package can be built into a .pkg installer on macOS using:

    cd Secretr_1.0.4_arm64_macos_pkg
    pkgbuild --root payload --scripts scripts --identifier com.verishore.secretr.pkg --version 1.0.4 Secretr.pkg
    productbuild --distribution Distribution.xml --package-path . Secretr_1.0.4.pkg

Or install manually (from target root):
    sudo rsync -a payload/ //
